﻿#！/bin/bash
dotnet BeetleX.WebApiBenchmarks.dll